package com.example.inventario.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.inventario.InventarioDBHelper
import com.example.inventario.screens.Movimiento
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.ui.platform.LocalContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaMovimientos(dbHelper: InventarioDBHelper, navController: NavHostController) {
    var tipo by remember { mutableStateOf("Entrada") }
    var expanded by remember { mutableStateOf(false) }
    val tipos = listOf("Entrada", "Salida")

    var fecha by remember { mutableStateOf("") }
    var codigo by remember { mutableStateOf("") }
    var cantidad by remember { mutableStateOf("") }
    var valorUnitario by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Registrar Movimiento", style = MaterialTheme.typography.headlineSmall)
        }

        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded },
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedTextField(
                readOnly = true,
                value = tipo,
                onValueChange = {},
                label = { Text("Tipo de Movimiento") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth()
            )
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                tipos.forEach { opcion ->
                    DropdownMenuItem(
                        text = { Text(opcion) },
                        onClick = {
                            tipo = opcion
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(value = fecha, onValueChange = { fecha = it }, label = { Text("Fecha") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = codigo, onValueChange = { codigo = it }, label = { Text("Código del Artículo") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = cantidad, onValueChange = { cantidad = it }, label = { Text("Cantidad") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = valorUnitario, onValueChange = { valorUnitario = it }, label = { Text("Valor Unitario") }, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = {
            val mov = Movimiento(
                tipo = tipo,
                fecha = fecha,
                codigo = codigo,
                cantidad = cantidad.toIntOrNull() ?: 0,
                valorUnitario = valorUnitario.toDoubleOrNull() ?: 0.0,
                promedio = valorUnitario.toDoubleOrNull() ?: 0.0
            )
            if (dbHelper.registrarMovimiento(mov)) {
                fecha = ""; codigo = ""; cantidad = ""; valorUnitario = ""
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Registrar Movimiento")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = { navController.navigate("inventario") }, modifier = Modifier.fillMaxWidth()) {
            Text("Volver al Inventario")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = { navController.navigate("historial") }, modifier = Modifier.fillMaxWidth()) {
            Text("Ver Historial de Movimientos")
        }
    }
}
